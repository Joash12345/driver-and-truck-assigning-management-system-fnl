
import { DriverType } from "@/pages/Drivers";

// Mock data for drivers
export const mockDrivers: DriverType[] = [
  {
    id: "D-001",
    name: "John Doe",
    licenseNumber: "CDL-123456",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    status: "driving",
    assignedVehicle: "T-001",
  },
  {
    id: "D-002",
    name: "Jane Smith",
    licenseNumber: "CDL-234567",
    email: "jane.smith@example.com",
    phone: "+1 (555) 234-5678",
    status: "driving",
    assignedVehicle: "T-002",
  },
  {
    id: "D-003",
    name: "Mike Johnson",
    licenseNumber: "CDL-345678",
    email: "mike.johnson@example.com",
    phone: "+1 (555) 345-6789",
    status: "available",
    assignedVehicle: null,
  },
  {
    id: "D-004",
    name: "Emily Davis",
    licenseNumber: "CDL-456789",
    email: "emily.davis@example.com",
    phone: "+1 (555) 456-7890",
    status: "off-duty",
    assignedVehicle: null,
  },
  {
    id: "D-005",
    name: "David Wilson",
    licenseNumber: "CDL-567890",
    email: "david.wilson@example.com",
    phone: "+1 (555) 567-8901",
    status: "available",
    assignedVehicle: null,
  },
  {
    id: "D-006",
    name: "Sarah Brown",
    licenseNumber: "CDL-678901",
    email: "sarah.brown@example.com",
    phone: "+1 (555) 678-9012",
    status: "inactive",
    assignedVehicle: null,
  },
  {
    id: "D-007",
    name: "Robert Taylor",
    licenseNumber: "CDL-789012",
    email: "robert.taylor@example.com",
    phone: "+1 (555) 789-0123",
    status: "available",
    assignedVehicle: null,
  },
  {
    id: "D-008",
    name: "Amanda Miller",
    licenseNumber: "CDL-890123",
    email: "amanda.miller@example.com",
    phone: "+1 (555) 890-1234",
    status: "driving",
    assignedVehicle: "T-003",
  },
];

// Filter drivers based on search term and status filter
export const filterDrivers = (searchTerm: string, statusFilter: string) => {
  return mockDrivers.filter((driver) => {
    const matchesSearch =
      driver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      driver.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      driver.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || driver.status === statusFilter;

    return matchesSearch && matchesStatus;
  });
};
