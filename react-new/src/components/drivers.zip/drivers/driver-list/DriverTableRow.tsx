
import { useNavigate } from "react-router-dom";
import {
  TableCell,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Edit, FileText, Mail, MoreHorizontal, Phone, Trash } from "lucide-react";
import { DriverType } from "@/pages/Drivers";
import { getInitials, getStatusBadge, getVehicleBadge } from "../utils/driverStatusUtils";

interface DriverTableRowProps {
  driver: DriverType;
}

const DriverTableRow = ({ driver }: DriverTableRowProps) => {
  const navigate = useNavigate();

  return (
    <TableRow
      key={driver.id}
      className="cursor-pointer hover:bg-muted/50"
      onClick={() => navigate(`/drivers/${driver.id}`)}
    >
      <TableCell>
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarFallback>
              {getInitials(driver.name)}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{driver.name}</div>
            <div className="text-xs text-muted-foreground">
              {driver.id}
            </div>
          </div>
        </div>
      </TableCell>
      <TableCell>{driver.licenseNumber}</TableCell>
      <TableCell>
        <div className="flex flex-col gap-1">
          <div className="flex items-center text-xs">
            <Mail className="h-3 w-3 mr-1 text-muted-foreground" />
            {driver.email}
          </div>
          <div className="flex items-center text-xs">
            <Phone className="h-3 w-3 mr-1 text-muted-foreground" />
            {driver.phone}
          </div>
        </div>
      </TableCell>
      <TableCell>{getStatusBadge(driver.status)}</TableCell>
      <TableCell>{getVehicleBadge(driver.assignedVehicle)}</TableCell>
      <TableCell className="text-right">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="h-8 w-8 p-0"
              onClick={(e) => e.stopPropagation()}
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              className="flex items-center gap-2 cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/drivers/${driver.id}`);
              }}
            >
              <FileText className="h-4 w-4" />
              <span>View Details</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center gap-2 cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                // Handle edit
              }}
            >
              <Edit className="h-4 w-4" />
              <span>Edit</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center gap-2 cursor-pointer text-destructive focus:text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                // Handle delete
              }}
            >
              <Trash className="h-4 w-4" />
              <span>Delete</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </TableCell>
    </TableRow>
  );
};

export default DriverTableRow;
