import React from "react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calendar,
  Clock,
  Edit,
  FileText,
  Mail,
  MapPin,
  Phone,
  Truck,
  User,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DriverType } from "@/pages/Drivers";

interface DriverDetailsProps {
  driver: DriverType;
}

const DriverDetails: React.FC<DriverDetailsProps> = ({ driver }) => {
  const navigate = useNavigate();
  
  const getStatusBadge = (status: string) => {
    const statusConfig: Record<
      string,
      { color: string; label: string; icon: React.ReactNode }
    > = {
      available: {
        color: "bg-green-100 text-green-800 hover:bg-green-200",
        label: "Available",
        icon: <User className="h-3 w-3 mr-1" />,
      },
      driving: {
        color: "bg-blue-100 text-blue-800 hover:bg-blue-200",
        label: "Driving",
        icon: <Truck className="h-3 w-3 mr-1" />,
      },
      "off-duty": {
        color: "bg-amber-100 text-amber-800 hover:bg-amber-200",
        label: "Off Duty",
        icon: null,
      },
      inactive: {
        color: "bg-slate-100 text-slate-800 hover:bg-slate-200",
        label: "Inactive",
        icon: null,
      },
    };

    const config = statusConfig[status] || statusConfig.inactive;

    return (
      <Badge
        variant="outline"
        className={`${config.color} border-none flex items-center px-3 py-1 text-sm`}
      >
        {config.icon}
        {config.label}
      </Badge>
    );
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="text-2xl">
                {getInitials(driver.name)}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-1 flex-1">
              <div className="flex flex-col md:flex-row md:items-center gap-2 mb-2">
                <h2 className="text-2xl font-bold">{driver.name}</h2>
                {getStatusBadge(driver.status)}
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  <span>ID: {driver.id}</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  <span>{driver.phone}</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  <span>{driver.email}</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 mt-4 md:mt-0">
              <Button variant="outline" className="gap-2">
                <Edit className="h-4 w-4" />
                <span>Edit Profile</span>
              </Button>
              <Button className="gap-2">
                <Truck className="h-4 w-4" />
                <span>Assign Vehicle</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="info" className="space-y-4">
        <TabsList>
          <TabsTrigger value="info">Driver Information</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="history">Trip History</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>
        
        <TabsContent value="info" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-4">
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Full Name</dt>
                    <dd className="text-sm font-semibold">{driver.name}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">License Number</dt>
                    <dd className="text-sm font-semibold">{driver.licenseNumber}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">License Type</dt>
                    <dd className="text-sm font-semibold">Commercial (Class A)</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">License Expiry</dt>
                    <dd className="text-sm font-semibold">{format(new Date(2024, 11, 31), "PPP")}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Date of Birth</dt>
                    <dd className="text-sm font-semibold">{format(new Date(1985, 5, 15), "PPP")}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Address</dt>
                    <dd className="text-sm font-semibold text-right">123 Main Street, Anytown, CA 12345</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Employment Details</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-4">
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Employee ID</dt>
                    <dd className="text-sm font-semibold">{driver.id}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Date Hired</dt>
                    <dd className="text-sm font-semibold">{format(new Date(2020, 3, 10), "PPP")}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Employment Type</dt>
                    <dd className="text-sm font-semibold">Full-time</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Department</dt>
                    <dd className="text-sm font-semibold">Long-haul Transport</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Supervisor</dt>
                    <dd className="text-sm font-semibold">Robert Johnson</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-muted-foreground">Emergency Contact</dt>
                    <dd className="text-sm font-semibold">Mary Doe - (555) 987-6543</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="h-5 w-5" />
                <span>Assigned Vehicle</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {driver.assignedVehicle ? (
                <div className="flex flex-col md:flex-row md:items-center justify-between">
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold">Volvo FH16</h3>
                    <div className="flex flex-col sm:flex-row gap-x-6 gap-y-1 text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <span>ID: {driver.assignedVehicle}</span>
                      </div>
                      <div className="flex items-center">
                        <span>License Plate: ABC-1234</span>
                      </div>
                      <div className="flex items-center">
                        <span>Model: 2022</span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="mt-4 md:mt-0"
                    onClick={() => navigate(`/trucks/${driver.assignedVehicle}`)}
                  >
                    View Vehicle Details
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">No vehicle currently assigned to this driver.</p>
                  <Button>Assign Vehicle</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Trips</CardTitle>
              <CardDescription>Scheduled trips for the next 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              {driver.status === "driving" ? (
                <div className="space-y-4">
                  <ScheduleItem
                    status="current"
                    origin="San Francisco, CA"
                    destination="Los Angeles, CA"
                    departureDate={new Date()}
                    arrivalDate={new Date(Date.now() + 86400000)}
                    truckId={driver.assignedVehicle}
                  />
                  
                  <ScheduleItem
                    status="upcoming"
                    origin="Los Angeles, CA"
                    destination="San Diego, CA"
                    departureDate={new Date(Date.now() + 172800000)}
                    arrivalDate={new Date(Date.now() + 216000000)}
                    truckId={driver.assignedVehicle}
                  />
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">No upcoming trips scheduled for this driver.</p>
                  <Button>Schedule New Trip</Button>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Weekly Schedule</CardTitle>
              <CardDescription>Driver's availability and work hours</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, index) => (
                  <div key={day} className="text-center">
                    <div className="mb-2 font-medium">{day}</div>
                    <div className={`rounded-md p-2 text-xs font-medium ${
                      index < 5 ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-800"
                    }`}>
                      {index < 5 ? "8:00 AM - 6:00 PM" : "Off"}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Trip History</CardTitle>
              <CardDescription>Recent trips completed by this driver</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="border-b pb-6 last:border-0 last:pb-0">
                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold">Route #{1000 + i}</h3>
                        <div className="text-sm text-muted-foreground">
                          {format(new Date(2023, 11, 15 - i * 5), "PPP")}
                        </div>
                      </div>
                      <Badge className="mt-2 md:mt-0 w-fit" variant="outline">
                        Completed
                      </Badge>
                    </div>
                    
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <div className="text-sm text-muted-foreground">Origin</div>
                        <div className="flex items-start gap-2">
                          <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                          <div>
                            <div className="font-medium">
                              {["New York, NY", "Chicago, IL", "Atlanta, GA"][i]}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Departed: {format(new Date(2023, 11, 15 - i * 5), "PPP")} at 8:00 AM
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="text-sm text-muted-foreground">Destination</div>
                        <div className="flex items-start gap-2">
                          <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                          <div>
                            <div className="font-medium">
                              {["Philadelphia, PA", "St. Louis, MO", "Miami, FL"][i]}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Arrived: {format(new Date(2023, 11, 16 - i * 5), "PPP")} at 2:00 PM
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex flex-wrap gap-3">
                      <div className="text-xs bg-muted px-2 py-1 rounded-md">
                        Distance: {[100, 295, 650][i]} miles
                      </div>
                      <div className="text-xs bg-muted px-2 py-1 rounded-md">
                        Duration: {[6, 8, 10][i]} hours
                      </div>
                      <div className="text-xs bg-muted px-2 py-1 rounded-md">
                        Cargo: {["Electronics", "Furniture", "Food Products"][i]}
                      </div>
                      <div className="text-xs bg-muted px-2 py-1 rounded-md">
                        Vehicle: T-00{i + 1}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle>Driver Documents</CardTitle>
              <CardDescription>License, certifications, and other important documents</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <DocumentItem
                  title="Commercial Driver's License"
                  number={driver.licenseNumber}
                  issueDate={new Date(2020, 0, 15)}
                  expiryDate={new Date(2024, 11, 31)}
                />
                
                <DocumentItem
                  title="Medical Certificate"
                  number="MED-789456"
                  issueDate={new Date(2023, 5, 10)}
                  expiryDate={new Date(2025, 5, 10)}
                />
                
                <DocumentItem
                  title="Hazardous Materials Endorsement"
                  number="HAZ-456123"
                  issueDate={new Date(2021, 2, 22)}
                  expiryDate={new Date(2026, 2, 22)}
                />
                
                <DocumentItem
                  title="Transportation Worker ID Card"
                  number="TWIC-123789"
                  issueDate={new Date(2022, 7, 5)}
                  expiryDate={new Date(2027, 7, 5)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface ScheduleItemProps {
  status: "current" | "upcoming" | "completed";
  origin: string;
  destination: string;
  departureDate: Date;
  arrivalDate: Date;
  truckId: string | null;
}

const ScheduleItem: React.FC<ScheduleItemProps> = ({
  status,
  origin,
  destination,
  departureDate,
  arrivalDate,
  truckId,
}) => {
  const statusStyles = {
    current: "border-primary/50 bg-primary/5",
    upcoming: "border-muted",
    completed: "border-muted bg-muted/10",
  };

  return (
    <div className={`border rounded-md p-4 ${statusStyles[status]}`}>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
        <h3 className="font-semibold">
          {status === "current" ? "Current Trip" : "Upcoming Trip"}
        </h3>
        {status === "current" && (
          <Badge className="bg-primary/20 text-primary hover:bg-primary/30 border-none w-fit mt-1 md:mt-0">
            In Progress
          </Badge>
        )}
      </div>
      
      <div className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">From</div>
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4 text-primary" />
              <span className="font-medium">{origin}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              <span>{format(departureDate, "PPP")}</span>
              <Clock className="h-3 w-3 ml-2" />
              <span>{format(departureDate, "p")}</span>
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">To</div>
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4 text-primary" />
              <span className="font-medium">{destination}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              <span>{format(arrivalDate, "PPP")}</span>
              <Clock className="h-3 w-3 ml-2" />
              <span>{format(arrivalDate, "p")}</span>
            </div>
          </div>
        </div>
        
        {truckId && (
          <div className="flex items-center gap-1 text-sm">
            <Truck className="h-4 w-4 text-muted-foreground" />
            <span>Vehicle: {truckId}</span>
          </div>
        )}
      </div>
    </div>
  );
};

interface DocumentItemProps {
  title: string;
  number: string;
  issueDate: Date;
  expiryDate: Date;
}

const DocumentItem: React.FC<DocumentItemProps> = ({
  title,
  number,
  issueDate,
  expiryDate,
}) => {
  const now = new Date();
  const isExpiringSoon = expiryDate.getTime() - now.getTime() < 90 * 24 * 60 * 60 * 1000; // 90 days
  const isExpired = expiryDate < now;
  
  return (
    <div className="flex flex-col md:flex-row items-start md:items-center justify-between p-4 border rounded-md">
      <div>
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          <h3 className="font-medium">{title}</h3>
        </div>
        <div className="ml-7 text-sm text-muted-foreground">
          {number}
        </div>
      </div>
      
      <div className="ml-7 md:ml-0 mt-2 md:mt-0 space-y-1 text-sm">
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground">Issued:</span>
          <span>{format(issueDate, "PPP")}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground">Expires:</span>
          <span className={isExpired ? "text-destructive font-medium" : isExpiringSoon ? "text-amber-500 font-medium" : ""}>
            {format(expiryDate, "PPP")}
            {isExpired && " (Expired)"}
            {!isExpired && isExpiringSoon && " (Expiring Soon)"}
          </span>
        </div>
      </div>
      
      <Button variant="outline" size="sm" className="ml-7 md:ml-0 mt-2 md:mt-0">
        View
      </Button>
    </div>
  );
};

export default DriverDetails;
