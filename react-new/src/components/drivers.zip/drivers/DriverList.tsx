
import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { filterDrivers } from "./data/driverData";
import DriverListFilters from "./driver-list/DriverListFilters";
import DriverTable from "./driver-list/DriverTable";
import DriverListPagination from "./driver-list/DriverListPagination";

const DriverList = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  // Filter drivers based on search term and status filter
  const filteredDrivers = filterDrivers(searchTerm, statusFilter);

  return (
    <Card>
      <CardHeader className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl">Driver Management</CardTitle>
            <CardDescription>
              Manage your drivers and their assignments
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 pt-0">
        <DriverListFilters
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
        />

        <DriverTable filteredDrivers={filteredDrivers} />

        <DriverListPagination />
      </CardContent>
    </Card>
  );
};

export default DriverList;
